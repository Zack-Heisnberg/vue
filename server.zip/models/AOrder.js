const mongoose = require('mongoose')

const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}

const order = new mongoose.Schema({
  auid: { type: String, required: true },
  cards: { type: [{ id: String, value: String }], default: [] },
  note: String,
  product: { type: String },
  type: { type: String },
  tdata: {
    typename: String,
    productname: lang,
    productimg: String,
  },
  usedcards: { type: [Number], default: [] },
  qt: { type: Number, min: 0, max: 1000 },
  sprice: { q: Number, p: Number, ps: Number },
  time: { type: Date, default: Date.now },
})

order.index({ time: -1 })

module.exports = mongoose.model('aorder', order)
