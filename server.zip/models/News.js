const mongoose = require('mongoose')
const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}

const anews = new mongoose.Schema({
  auid: { type: String, required: true },
  icon: { type: String, default: 'fas fa-newspaper' },
  title: { type: lang, required: true },
  text: { type: lang, required: true },
  extra: { type: lang, required: true },
  time: { type: Date, default: Date.now },
})
const slide = new mongoose.Schema({
  auid: { type: String, required: true },
  image: { type: String, required: true },
  title: { type: lang, required: true },
  text: { type: lang, required: true },
  extra: { type: lang, required: true },
  time: { type: Date, default: Date.now },
})
module.exports = {
  news: mongoose.model('News', anews),
  slide: mongoose.model('slides', slide),
}
