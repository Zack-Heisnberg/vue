const mongoose = require('mongoose')

const NotifyAdmins = require('../utils/nota')

const Log = {
  method: String,
  url: String,
  ip: String,
  useragent: String,
  uid: String,
  query: { type: String, default: '' },
  body: { type: String, default: '' },
  time: { type: Date, default: Date.now },
}

const alog = new mongoose.Schema(Log, {
  capped: { size: 1048576 },
})

const SLog = new mongoose.Schema({
  aid: { type: Log },
  uid: String,
  type: {
    type: String,
    enum: [
      'Admin',
      'Auth',
      'Parser',
      'Get',
      '404',
      'Set',
      'Upload',
      'Fullfill',
    ],
  },
  message: String,
  handled: { type: Boolean, default: false },
  handle: {
    ban: Boolean,
    auid: String,
    note: String,
    time: Date,
  },
  time: { type: Date, default: Date.now },
})

SLog.post('save', async function (doc) {
  await NotifyAdmins(
    doc.type,
    'Id: ' + doc._id + ' Msg: ' + doc.message,
    'negative',
    'ID' + doc._id,
    '/admin-security/' + doc._id
  )
})
const FLog = new mongoose.Schema({
  aid: { type: Log },
  uid: String,
  name: String,
  filename: String,
  mime: String,
  id: { type: String, required: true },
  time: { type: Date, default: Date.now },
})

module.exports = {
  Alog: mongoose.model('Api-Log', alog),
  Slog: mongoose.model('Security-Log', SLog),
  Flog: mongoose.model('File-Log', FLog),
}
