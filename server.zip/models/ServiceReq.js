const mongoose = require('mongoose')

const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}
const reqf = mongoose.Schema({
  name: { type: String },
  value: { type: String },
  _id: { id: false },
})

const service = new mongoose.Schema({
  uid: { type: String, required: true },
  status: {
    type: String,
    enum: ['PA', 'DA', 'PU', 'DU', 'AU', 'HH', 'HA'],
  },
  reqfields: [reqf],
  res: [{ auid: String, rtype: String, note: String, time: Date }],
  product: { type: String },
  tdata: {
    productname: lang,
    productimg: String,
  },
  price: { type: Number },
  bprice: { type: Number },
  time: { type: Date, default: Date.now },
})
service.index({ time: -1, uid: 1, status: 1, product: 1 })

module.exports = mongoose.model('servicereq', service)
