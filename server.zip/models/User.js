const mongoose = require('mongoose')
const userSchema = new mongoose.Schema({
  fullName: { type: String, required: true },
  email: { type: String, required: false },
  auth: {
    google: { type: String, required: false },
    facebook: { type: String, required: false },
  },
  flaged: { type: Boolean, default: false },
  flagenote: { type: String },
  fcmtokens: {
    pc: { type: String, default: '' },
    mobile: { type: String, default: '' },
    lang: {
      type: String,
      enum: ['en', 'fr', 'ar', 'en-us'],
    },
    news: { type: Boolean, default: false },
    account: { type: Boolean, default: false },
    messages: { type: Boolean, default: false },
  },
  image: { type: String, default: './avatar.png' },
  phoneNumber: { type: String, required: true },
  discount: { type: Number, default: 0 },
  uid: { type: String, index: { unique: true }, required: true },
  money: { type: Number, min: 0, default: 0 },
  userstats: {
    totm: { type: Number, min: 0, default: 0 }, // spent money
    at: { type: Number, min: 0, default: 0 }, // acceped  topup
    ct: { type: Number, min: 0, default: 0 }, // Canceled topup
    dt: { type: Number, min: 0, default: 0 }, // denied topup
    pb: { type: Number, min: 0, default: 0 }, // borrowd topup
    pba: { type: Number, min: 0, default: 0 }, // borrowd ammount
    tot: { type: Number, min: 0, default: 0 }, // recharged
    pt: { type: Number, min: 0, default: 0 }, // pending topup
    toto: { type: Number, min: 0, default: 0 }, // total order
    po: { type: Number, min: 0, default: 0 }, // pending order
    co: { type: Number, min: 0, default: 0 }, // cancled order
  },
  pts: { type: Number, min: 0, default: 0 },
  time: { type: Date, default: Date.now },
})

module.exports = mongoose.model('User', userSchema)
