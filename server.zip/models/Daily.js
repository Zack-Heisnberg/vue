const mongoose = require('mongoose')

const activitySchema = new mongoose.Schema({
  time: Date,
  product: String,
  type: String,
  onum: { type: Number, min: 0, default: 0 },
  snum: { type: Number, min: 0, default: 0 },
  cnum: { type: Number, min: 0, default: 0 },
  i: { type: Number, min: 0, default: 0 },
  o: { type: Number, min: 0, default: 0 },
})

activitySchema.index({ time: -1 })
module.exports = mongoose.model('Daily', activitySchema)
