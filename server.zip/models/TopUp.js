const mongoose = require('mongoose')

const topupSchema = new mongoose.Schema({
  uid: { type: String, required: true },
  status: {
    type: String,
    enum: ['WP', 'WAB', 'WAP', 'A', 'D', 'B', 'C'],
  },
  method: {
    type: String,
    enum: ['Baridimob', 'Paysera', 'CCP', 'Direct'],
  },
  borrowed: { type: Boolean, default: false },
  handle: [
    {
      auid: String,
      payload: String,
      time: Date,
    },
  ],
  proof: [
    {
      name: String,
      filename: String,
      mime: String,
      thumb: String,
      id: String,
    },
  ],
  amount: { type: Number, min: 0 },
  time: { type: Date, default: Date.now },
})
topupSchema.index({ time: -1, uid: 1 })

module.exports = mongoose.model('topup', topupSchema)
