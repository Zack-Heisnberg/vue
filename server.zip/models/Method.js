const mongoose = require('mongoose')
const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}

const methodSchema = new mongoose.Schema({
  enabled: { type: Boolean, required: true },
  type: {
    type: String,
    enum: ['Baridimob', 'Paysera', 'CCP', 'Direct'],
  },
  description: lang,
  conversion: { type: Number, min: 0, default: 1 },
  fee: { type: Number, min: 0, default: 1 },
  min: { type: Number, min: 0, default: 2000 },
  max: { type: Number, min: 0, default: 50000 },
  time: { type: Date, default: Date.now },
})

module.exports = mongoose.model('method', methodSchema)
