var logger = require('pino')()
const express = require('express')
const app = express()
const chalk = require('chalk')
const MD5 = require('./utils/m5')
const axios = require('axios')
const admin = require('firebase-admin')
const FBserviceAccount = require('./config/fbadmin.json')
var cors = require('cors')

let Color = {}
Color.success = chalk.bold.cyan
Color.warn = chalk.bold.yellow
Color.green = chalk.bold.green
Color.accent = chalk.bold.magenta
const init = async () => {
  console.log(
    '*************** ' +
      Color.success('Zh-Ecard-Store') +
      ' Server - ' +
      Color.accent('0.0.1') +
      ' ****************'
  )
  let allow = false
  logger.info('Starting Logger')
  logger.info('Getting Configs')
  require('dotenv').config()
  logger.info('Checking Config')
  /*
  let lc
  try {
    lc = await axios.get('https://dz-zh.cyou/api/zhecardlc.json')
  } catch (er) {
    logger.info('Booting Failed')
    return
  }
  let sk = false
  let bp = false
  if (MD5(FBserviceAccount.project_id) + 99 !== lc.data['z0.0.1-tionline-2']) {
    sk = true
    bp = true
    logger.error('App Boot failed')
    return
  }
  if (MD5(process.env.MONGO_HOST) + 62 == lc.data['z0.0.1-tionline']) {
    allow = true
    logger.error('App Boot failed')
    return
  }
  let allow2 = true
  console.log(
    '*************** ' +
      Color.success('Zh-Ecard-Store') +
      ' Server - ' +
      Color.accent('Starting Utils') +
      ' ****************'
  )
  if (MD5(process.env.MONGO_HOST) + 62 == lc.data['z0.0.1-tionline']) {
    allow2 = false
    return
  }
  logger.info('GDrive Init')
  
  // require('./routes/test.js')
  if (!bp) {
    if (!sk) {
      
    } else {
      logger.error('App Boot failed')
      return
    }
  } else {
    logger.error('App Boot failed')
    return
  }
  console.log(
    '*************** ' +
    Color.success('Zh-Ecard-Store') +
    ' Server - ' +
    Color.accent('Starting DB') +
    ' ****************'
    )
      if (!bp) {
    if (!sk) {
      try {
        await require('./boot/mongo')()
      } catch (error) {
        logger.error(error)
        logger.info('Boot Failed')
        return
      }
    }
  }
    */
  logger.info('Firebase Admin Init')
  await require('./boot/gdrive')()
  admin.initializeApp({
    credential: admin.credential.cert(FBserviceAccount),
  })
  logger.info('Loading Models')

  await require('./boot/mongo')()
  logger.info('DB Connected')
  console.log(
    '*************** ' +
      Color.success('Zh-Ecard-Store') +
      ' Server - ' +
      Color.accent('Starting Routes') +
      ' ****************'
  )
  logger.info('Loading Routes')
  app.use(cors())
  const router = require('./routes')
  app.use('/', router)

  logger.info('Starting Api Server')

  require('./routes/index.js')
  let port = process.env.PORT || 3000
  app.listen(port)
  logger.info('APP Is listening at: ' + port)

  console.log(
    '*************** ' +
      Color.success('Zh-Ecard-Store') +
      ' Server - ' +
      Color.green('All Services Working') +
      ' ****************'
  )
}
init()

// Error Handlers
/*
process.on('unhandledRejection', async (err) => {
  console.error('Unhandled rejection: ', err)
})

process.on('uncaughtException', async (err) => {
  console.error('Uncaught exception: ', err)
})
*/
