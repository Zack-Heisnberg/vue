const mongoose = require('mongoose')
const { Slog } = require('../models/Logs')
const logger = require('pino')()
const User = require('../models/User')
const UNotify = require('../utils/notu')
const Activity = require('../models/Activity')
const Daily = require('../models/Daily')
const { product, card } = require('../models/Category')
const { decrypt } = require('../utils/enc')
const Order = require('../models/Order')
const Wallet = require('../models/Wallet')
module.exports = async function (id) {
  const session2 = await mongoose.connection.startSession()
  const opts2 = { session2 }
  try {
    const aOrder = await Order.findOneAndUpdate({ _id: id }, { handling: true })
    if (!aOrder) {
      throw new Error('No order with this ID')
    }
    if (aOrder.status == 'FF') {
      throw new Error('Fullfiled ORDER')
    }
    if (aOrder.status == 'C') {
      throw new Error('CANCLED ORDER')
    }
    if (aOrder.status == 'R') {
      throw new Error('REFUNDED ORDER')
    }
    if (aOrder.handling) {
      throw new Error('Being Handled')
    }
    await session2.withTransaction(async () => {
      const aOrder = await Order.findOne({ _id: id }, null, opts2)
      if (aOrder.status == 'C') {
        throw new Error('CANCLED ORDER')
      }
      if (aOrder.status == 'R') {
        throw new Error('REFUNDED ORDER')
      }
      let cards = []

      if (aOrder.cards) {
        cards = aOrder.cards
      }
      let needed = aOrder.qt
      let newcards = 0
      let newbuy = 0
      if (cards.length == needed) {
        throw new Error('HEY ITS FULLFILLED')
      }
      let promises = []
      for (let index = 0; index < parseInt(needed - cards.length); index++) {
        promises.push(
          card
            .findOneAndUpdate(
              { product: aOrder.product, type: aOrder.type, sold: false },
              { $set: { sold: true, sorder: aOrder._id.toString() } },
              { fields: { value: 1, bprice: 1 } }
            )
            .session(session2)
            .lean()
        )
      }
      let res = await Promise.all(promises)

      res.forEach((element) => {
        if (element) {
          cards.push({
            id: element._id,
            value: decrypt(element.value),
          })
          newcards++
          newbuy += element.bprice
        }
      })
      let newst = ''
      if (cards.length == 0) {
        newst = 'NF'
      } else if (cards.length < needed) {
        newst = 'PF'
      } else if (cards.length == needed) {
        newst = 'FF'
      }
      if (cards.length > needed) {
        throw new Error('Nchlh brabi')
      }
      let spromises = []
      spromises.push(
        Order.findByIdAndUpdate(
          { _id: id },
          { status: newst, cards: cards }
        ).session(session2)
      )
      let fforpf
      let num
      if (newst !== 'FF') {
        num = 0
        fforpf = ' Partially Filled'
        spromises.push(
          product
            .updateOne(
              { _id: aOrder.product },
              {
                $inc: {
                  'types.$[elem].needed': -newcards,
                  'types.$[elem].cur': newcards,
                },
              },
              { arrayFilters: [{ 'elem._id': aOrder.type }] }
            )
            .session(session2)
        )
      } else {
        num = -1
        fforpf = ' Fullfilled'
        spromises.push(
          Wallet.updateOne(
            { _id: '123456789012345678901234' },
            {
              $inc: { totpo: -1 },
            },
            {
              new: true,
              upsert: true, // Make this update into an upsert
            }
          ).session(session2)
        )
        spromises.push(
          product
            .updateOne(
              { _id: aOrder.product },
              {
                $inc: {
                  'types.$[elem].cur': newcards,
                  'types.$[elem].needed': -newcards,
                },
              },
              { arrayFilters: [{ 'elem._id': aOrder.type }] }
            )
            .session(session2)
        )
      }
      let user = await User.findOneAndUpdate(
        { uid: aOrder.uid },
        {
          $inc: {
            'userstats.po': num,
          },
        },
        { fields: { fcmtokens: 1 } }
      )
        .lean()
        .session(session2)
      if (cards.length > 0 && newcards) {
        await UNotify(
          user.fcmtokens,
          'Order ' + fforpf,
          'Order ' + aOrder._id.toString() + ' was ' + fforpf,
          'positive',
          aOrder._id.toString(),
          '/order/' + aOrder._id.toString()
        )
      }
      let totsell = parseInt(newcards) * aOrder.sprice.p
      let today = new Date()
      today = today.setHours(0, 0, 0, 0)
      spromises.push(
        Daily.updateOne(
          {
            time: today,
            product: aOrder.tdata.productname.en,
            type: aOrder.tdata.typename,
          },
          {
            $inc: {
              cnum: newcards,
              i: totsell,
              o: newbuy,
            },
          },
          {
            upsert: true,
          }
        ).session(session2),
        Daily.updateOne(
          { time: today, product: 'ALL', type: 'ALL' },
          {
            $inc: {
              cnum: newcards,
              i: totsell,
              o: newbuy,
            },
          },
          {
            upsert: true,
          }
        ).session(session2)
      )
      spromises.push(
        Activity.create(
          [
            {
              uid: aOrder.uid,
              type: 'Order',
              ip: 'SERVER',
              ua: 'SERVER',
              description: newst,
              params: [
                aOrder._id.toString(),
                needed,
                aOrder.tdata.productname.en,
                aOrder.tdata.typename,
              ],
            },
          ],
          opts2
        )
      )
      await Promise.all(spromises)
    })
  } catch (error) {
    try {
      await Slog.create({
        type: 'Fullfill',
        aid: { useragent: 'Server' },
        message: error.message,
      })
    } catch (err) {
      logger.error(error, ' error not loged ')
    }
  } finally {
    await session2.endSession()
    await Order.findOneAndUpdate({ _id: id }, { handling: false })
  }
}
