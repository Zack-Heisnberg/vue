const logger = require('pino')()
const admin = require('firebase-admin')
const Daily = require('../models/Daily')
const mongoose = require('mongoose')
const NewsNotify = require('../utils/newnot')
const ANotify = require('../utils/nota')
const UNotify = require('../utils/notu')
const refill = require('../utils/refill')
const { encrypt, decrypt } = require('../utils/enc')
const { Slog, Flog } = require('../models/Logs')
const User = require('../models/User')
const { news, slide } = require('../models/News')
const { category, product, service, card } = require('../models/Category')
const Activity = require('../models/Activity')
const Order = require('../models/Order')
const AOrder = require('../models/AOrder')
const ServiceReq = require('../models/ServiceReq')
const TopUp = require('../models/TopUp')
const Wallet = require('../models/Wallet')
const Method = require('../models/Method')
const Discount = require('../models/Discount')
const { google } = require('googleapis')
const key = require('../config/gdrive.json')
const drive = google.drive('v3')
const jwtClient = new google.auth.JWT(
  key.client_email,
  null,
  key.private_key,
  ['https://www.googleapis.com/auth/drive'],
  null
)
module.exports = async function fb(req, res) {
  Object.keys(req.body).forEach(function (key) {
    if (/\$/g.test(req.body[key])) {
      req.body[key].replace(/\$/g, '\uFF04')
      Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Admin',
        message:
          'Possible Query injection at params ' +
          key +
          ' value ' +
          req.body[key],
      })
    }
    req.alogid.body = JSON.stringify(req.body)
  })
  try {
    if (req.params.name == 'wallet') {
      const payload = JSON.parse(req.body.payload)
      if (req.params.settings == 'clear') {
        await Wallet.updateOne(
          { _id: '123456789012345678901234' },
          {
            $unset: {
              Methods: 1,
              AOrders: 1,
            },
            totct: 0,
            lastclear: {
              auid: req.auid,
              time: Date.now(),
            },
            since: Date.now(),
          }
        )
        await ANotify(
          'Wallet Cleared',
          payload.todo + ' - Admin ' + req.auid,
          'info',
          payload.todo,
          'nourl'
        )
        res.json({ done: true })
        return
      }
      return
    }
    if (req.params.name == 'todo') {
      const payload = JSON.parse(req.body.payload)
      if (req.params.settings == 'add') {
        await Wallet.updateOne(
          { _id: '123456789012345678901234' },
          {
            $push: {
              todos: {
                todo: payload.todo,
                todo_desc: payload.todo_desc,
                image: payload.image,
              },
            },
          }
        )
        await ANotify(
          'New ToDo',
          payload.todo + ' - Admin ' + req.auid,
          'info',
          payload.todo,
          'nourl'
        )
        res.json({ done: true })
        return
      }
      if (req.params.settings == 'done') {
        await Wallet.updateOne(
          { _id: '123456789012345678901234' },
          { 'todos.$[elem].completed': true },
          { arrayFilters: [{ 'elem._id': req.body.id }] }
        )
        await ANotify(
          'ToDo Done',
          payload.todo + ' - Admin ' + req.auid,
          'info',
          payload.todo,
          'nourl'
        )
        res.json({ done: true })
        return
      }
      if (req.params.settings == 'del') {
        await Wallet.updateOne(
          { _id: '123456789012345678901234' },
          {
            $pull: {
              todos: { _id: req.body.id },
            },
          }
        )
        await ANotify(
          'ToDo Removed',
          payload.todo + ' - Admin ' + req.auid,
          'info',
          payload.todo,
          'nourl'
        )
        res.json({ done: true })
        return
      }
      return
    }
    if (req.params.name == 'neworder') {
      const session = await mongoose.connection.startSession()
      const opts = { session }
      //const opts = { session }
      try {
        await session.withTransaction(async () => {
          const payload = JSON.parse(req.body.payload)
          // product less cards
          const prod = await product
            .findOneAndUpdate(
              { _id: payload.product },
              {
                $inc: {
                  'types.$[elem].cur': payload.qt,
                },
              },
              { arrayFilters: [{ 'elem._id': payload.type }] }
            )
            .session(session)
            .lean()
          if (prod.types[0].cur < 0) {
            throw new Error('Sad Life no more cards')
          }
          // order
          let myorder = await AOrder.create(
            [
              {
                auid: req.auid,
                cards: [],
                note: payload.note,
                product: payload.product,
                type: payload.type,
                tdata: {
                  typename: prod.types[0].name,
                  productname: prod.title,
                  productimg: prod.image,
                },
                qt: payload.qt,
                sprice: { q: 0, p: payload.price, ps: 0 },
              },
            ],
            opts
          )
          // look for cards
          let promises = []
          let cards = []
          let newbuy = 0
          for (let index = 0; index < payload.qt; index++) {
            promises.push(
              card
                .findOneAndUpdate(
                  {
                    product: myorder[0].product,
                    type: myorder[0].type,
                    sold: false,
                  },
                  {
                    $set: {
                      sold: true,
                      adsold: true,
                      adauid: req.auid,
                      sorder: myorder[0]._id.toString(),
                    },
                  },
                  { fields: { value: 1, bprice: 1 } }
                )
                .session(session)
                .lean()
            )
          }
          let resp = await Promise.all(promises)
          resp.forEach((element) => {
            if (element) {
              cards.push({
                id: element._id,
                value: decrypt(element.value),
              })
              newbuy += parseInt(element.bprice)
            }
          })
          // cards and tdata auid
          if (cards.length < parseInt(payload.qt)) {
            throw new Error('Sad Life no more cards')
          }
          await AOrder.findByIdAndUpdate(
            { _id: myorder[0]._id.toString() },
            { cards: cards }
          ).session(session)
          // wallet and daily
          let totsell = parseInt(payload.qt) * parseInt(payload.price)
          let today = new Date()
          today = today.setHours(0, 0, 0, 0)
          await Daily.updateOne(
            { time: today, product: 'ALL', type: 'ALL' },
            {
              $inc: {
                onum: 1,
                cnum: payload.qt,
                i: totsell,
                o: newbuy,
              },
            },
            {
              upsert: true,
            }
          ).session(session)
          await Daily.updateOne(
            { time: today, product: myorder[0].product, type: myorder[0].type },
            {
              $inc: {
                onum: 1,
                cnum: payload.qt,
                i: totsell,
                o: newbuy,
              },
            },
            {
              upsert: true,
            }
          ).session(session)
          const methb = 'AOrders.' + req.auid
          await Wallet.updateOne(
            { _id: '123456789012345678901234' },
            {
              $inc: { [methb]: totsell },
            },
            {
              new: true,
              upsert: true, // Make this update into an upsert
            }
          ).session(session)
          //
          res.json({ done: true })
        })
      } catch (error) {
        throw new Error(error)
      } finally {
        await session.endSession()
      }
      return
    }
    if (req.params.name == 'corder') {
      const session = await mongoose.connection.startSession()
      const opts = { session }
      try {
        const aOrder = await Order.findOneAndUpdate(
          { _id: req.body.id },
          { handling: true }
        )
        if (!aOrder) {
          throw new Error('No order with this ID')
        }
        if (aOrder.status == 'FF') {
          throw new Error('Fullfiled ORDER')
        }
        if (aOrder.cards && aOrder.cards.length == aOrder.qt) {
          throw new Error('Fullfiled ORDER')
        }
        if (aOrder.status == 'C') {
          throw new Error('CANCELED ORDER')
        }
        if (aOrder.handling) {
          throw new Error('Being Handled')
        }
        await session.withTransaction(async () => {
          const aOrder = await Order.findOne({ _id: req.body.id }, null, opts)
          let sprice = aOrder.sprice
          let refqt = aOrder.qt
          if (aOrder.cards.length) {
            refqt = aOrder.qt - aOrder.cards.length
          }
          // founding Price for qt
          let amount = parseInt(sprice.p * parseInt(refqt))
          let ptstd = parseInt(sprice.ps * parseInt(refqt))
          // alright let get down to buisness
          const aOrder2 = await Order.findOneAndUpdate(
            { _id: req.body.id },
            {
              status: 'C',
            }
          )
            .lean()
            .session(session)
          if (aOrder2.status == 'FF') {
            throw new Error('Fullfiled ORDER')
          }
          if (aOrder2.cards == aOrder2.card) {
            throw new Error('CHANGED cards')
          }
          await Wallet.updateOne(
            { _id: '123456789012345678901234' },
            {
              $inc: { totpo: -1 },
            },
            {
              new: true,
              upsert: true, // Make this update into an upsert
            }
          ).session(session)
          await product
            .updateOne(
              { _id: aOrder.product },
              {
                $inc: {
                  'types.$[elem].needed': -refqt,
                },
              },
              { arrayFilters: [{ 'elem._id': aOrder.type }] }
            )
            .session(session)
          let user = await User.findOneAndUpdate(
            { uid: aOrder.uid },
            {
              $inc: {
                'userstats.totm': -amount,
                'userstats.po': -1,
                money: amount,
                pts: -ptstd,
              },
            }
          )
            .lean()
            .session(session)
          await Activity.create(
            [
              {
                uid: req.decodedToken.uid,
                type: 'Order',
                ip: 'ADMIN ' + req.auid,
                ua: '',
                description: 'C',
                params: [
                  aOrder._id.toString(),
                  aOrder.qt,
                  aOrder.tdata.productname.en,
                  aOrder.tdata.typename,
                ],
              },
            ],
            opts
          )
          await UNotify(
            user.fcmtokens,
            'Order Canceled',
            'Order ' + aOrder._id.toString() + ' was Canceled',
            'positive',
            aOrder._id.toString(),
            'nourl'
          )
          res.json({ done: true })
        })
      } catch (error) {
        throw new Error(error)
      } finally {
        await session.endSession()
        await Order.findOneAndUpdate({ _id: req.body.id }, { handling: false })
      }
      return
    }
    if (req.params.name == 'refill') {
      res.json({ done: true })
      await refill(req.body.id)
      return
    }
    if (req.params.name == 'user') {
      if (req.params.settings == 'ban') {
        const payload = JSON.parse(req.body.payload)
        console.log(payload)
        if (payload.flag) {
          await admin.auth().updateUser(payload.uid, {
            disabled: true,
          })
          await User.findOneAndUpdate(
            { uid: payload.uid },
            {
              flaged: true,
              flagenote: payload.note + ' - ' + req.auid + ' - ' + Date.now(),
            }
          )
        } else {
          await admin.auth().updateUser(payload.uid, {
            disabled: false,
          })
          await User.findOneAndUpdate(
            { uid: payload.uid },
            {
              flaged: false,
              flagenote: payload.note + req.auid + '-' + Date.now(),
            }
          )
        }
      } else if (req.params.settings == 'notify') {
        const payload = JSON.parse(req.body.payload)
        await UNotify(
          payload.fcmtokens,
          payload.title,
          payload.message,
          'info',
          payload.message,
          'nourl'
        )
      } else {
        throw new Error('404 - admins - user')
      }
      res.json({ done: true })
      return
    }
    if (req.params.name == 'notify') {
      await ANotify(
        'Handled',
        'Request id' + req.body.id + ' was handled by ' + req.auid,
        'info',
        req.body.id,
        'nourl'
      )
      res.json({ done: true })
      return
    }
    if (req.params.name == 'topup') {
      const session = await mongoose.connection.startSession()
      let Atopup = { proof: [] }
      try {
        await session.withTransaction(async () => {
          const id = req.body.id
          const auid = req.auid
          const payload = JSON.parse(req.body.payload)
          if (payload.borrowed) {
            if (payload.accept) {
              const newtopup = {
                status: 'A',
                $push: {
                  handle: {
                    auid: auid,
                    payload: req.body.payload,
                    time: Date.now(),
                  },
                },
              }
              // topup
              Atopup = await TopUp.findOneAndUpdate({ _id: id }, newtopup)
                .lean()
                .session(session)
              const newuser = {
                $inc: {
                  'userstats.pb': -1,
                  'userstats.at': 1,
                  'userstats.pba': -parseInt(payload.amount),
                  'userstats.tot': parseInt(payload.amount),
                },
              }
              let meth
              let methb
              if (Atopup.method == 'Direct') {
                meth = 'Methods.' + 'Direct.' + req.auid
              } else {
                meth = 'Methods.' + Atopup.method
              }
              if (Atopup.method == 'Direct') {
                methb = 'Borrows.' + 'Direct.' + req.auid
              } else {
                methb = 'Borrows.' + Atopup.method
              }
              const newwallet = {
                $inc: {
                  totbt: -1,
                  totct: 1,
                  [methb]: -Atopup.amount,
                  [meth]: Atopup.amount,
                },
              }

              if (Atopup.status !== 'B' && Atopup.status !== 'WAP') {
                throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
              }
              // user
              let user = await User.findOneAndUpdate(
                { uid: Atopup.uid },
                newuser
              )
                .session(session)
                .lean()
                .select({ fcmtokens: 1 })
              await Activity.create(
                [
                  {
                    uid: Atopup.uid,
                    type: 'TopUp',
                    ip: 'ADMIN-IP ' + req.auid,
                    ua: 'ADMIN-UA',
                    description: 'BRA',
                    params: [Atopup._id, Atopup.method, Atopup.amount],
                  },
                ],
                session
              )
              // wallet
              await Wallet.updateOne(
                { _id: '123456789012345678901234' },
                newwallet,
                {
                  new: true,
                  upsert: true, // Make this update into an upsert
                }
              ).session(session)
              await UNotify(
                user.fcmtokens,
                'TopUp Accepted',
                'TopUp' + id + ' payment was accepted',
                'positive',
                id,
                '/topup/' + id
              )
              // daily
            } else {
              Atopup = await TopUp.findOneAndUpdate(
                { _id: id },
                {
                  status: 'B',
                  $push: {
                    handle: {
                      auid: auid,
                      payload: req.body.payload,
                      time: Date.now(),
                    },
                  },
                }
              )
                .lean()
                .session(session)
              if (Atopup.status !== 'B' && Atopup.status !== 'WAP') {
                throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
              }
              // user
              let user = await User.findOne({ uid: Atopup.uid })
                .lean()
                .select({ fcmtokens: 1 })
                .session(session)
              await Activity.create(
                [
                  {
                    uid: Atopup.uid,
                    type: 'TopUp',
                    ip: 'ADMIN-IP ' + req.auid,
                    ua: 'ADMIN-UA',
                    description: 'BRR',
                    params: [Atopup._id, Atopup.method, Atopup.amount],
                  },
                ],
                session
              )
              await UNotify(
                user.fcmtokens,
                'TopUp Denied',
                'Sorry, but TopUp ' + id + ' payment was denied :(',
                'negative',
                id,
                '/topup/' + id
              )
            }
            res.json({ done: true })
            // rmproof
            if (Atopup.proof.length && payload.rmproof) {
              Atopup.proof.forEach(async (element) => {
                try {
                  await drive.files.delete({
                    auth: jwtClient,
                    fileId: element.id,
                  })
                } catch (er) {
                  logger.error(er)
                }
              })
            }
            return
          }
          if (payload.accept) {
            const newtopup = {
              status: payload.borrow ? 'B' : 'A',
              borrowed: payload.borrow,
              $push: {
                handle: {
                  auid: auid,
                  payload: req.body.payload,
                  time: Date.now(),
                },
              },
            }
            // topup
            Atopup = await TopUp.findOneAndUpdate({ _id: id }, newtopup)
              .lean()
              .session(session)
            const newuser = {
              $inc: {
                money: parseInt(payload.amount),
                'userstats.pt': -1,
                [payload.borrow ? 'userstats.pb' : 'userstats.at']: 1,
                [payload.borrow ? 'userstats.pba' : 'userstats.tot']: parseInt(
                  payload.amount
                ),
              },
              discount: parseInt(payload.level),
            }
            let meth
            const ttt = payload.borrow ? 'Borrows.' : 'Methods.'
            if (Atopup.method == 'Direct') {
              meth = ttt + 'Direct.' + req.auid
            } else {
              meth = ttt + Atopup.method
            }
            const newwallet = {
              $inc: {
                totpt: -1,
                [payload.borrow ? 'totbt' : 'totct']: 1,
                [meth]: Atopup.amount,
              },
            }

            if (
              Atopup.status !== 'WP' &&
              Atopup.status !== 'WAP' &&
              Atopup.status !== 'WAB'
            ) {
              throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
            }
            // user
            let user = await User.findOneAndUpdate({ uid: Atopup.uid }, newuser)
              .session(session)
              .lean()
              .select({ fcmtokens: 1 })
            await Activity.create(
              [
                {
                  uid: Atopup.uid,
                  type: 'TopUp',
                  ip: 'ADMIN-IP ' + req.auid,
                  ua: 'ADMIN-UA',
                  description: 'TS',
                  params: [Atopup._id, Atopup.method, Atopup.amount],
                },
              ],
              session
            )
            // wallet
            await Wallet.updateOne(
              { _id: '123456789012345678901234' },
              newwallet,
              {
                new: true,
                upsert: true, // Make this update into an upsert
              }
            ).session(session)
            await UNotify(
              user.fcmtokens,
              'TopUp Accepted',
              'TopUp' + id + ' was accepted :)',
              'positive',
              id,
              '/topup/' + id
            )
            // daily
          } else {
            // topup
            Atopup = await TopUp.findOneAndUpdate(
              { _id: id },
              {
                status: 'D',
                $push: {
                  handle: {
                    auid: auid,
                    payload: req.body.payload,
                    time: Date.now(),
                  },
                },
              }
            )
              .lean()
              .session(session)
            if (
              Atopup.status !== 'WP' &&
              Atopup.status !== 'WAP' &&
              Atopup.status !== 'WAB'
            ) {
              throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
            }
            // user
            let user = await User.findOneAndUpdate(
              { uid: Atopup.uid },
              { $inc: { 'userstats.pt': -1, 'userstats.dt': 1 } }
            )
              .lean()
              .select({ fcmtokens: 1 })
              .session(session)
            await Activity.create(
              [
                {
                  uid: Atopup.uid,
                  type: 'TopUp',
                  ip: 'ADMIN-IP ' + req.auid,
                  ua: 'ADMIN-UA',
                  description: 'TR',
                  params: [Atopup._id, Atopup.method, Atopup.amount],
                },
              ],
              session
            )
            // wallet
            await Wallet.updateOne(
              { _id: '123456789012345678901234' },
              {
                $inc: { totpt: -1 },
              },
              {
                new: true,
                upsert: true, // Make this update into an upsert
              }
            ).session(session)
            await UNotify(
              user.fcmtokens,
              'TopUp Denied',
              'Sorry, but topup ' + id + ' was denied',
              'negative',
              id,
              '/topup/' + id
            )
          }
          res.json({ done: true })
          // rmproof
          if (Atopup.proof.length && payload.rmproof) {
            Atopup.proof.forEach(async (element) => {
              try {
                await drive.files.delete({
                  auth: jwtClient,
                  fileId: element.id,
                })
              } catch (er) {
                logger.error(er)
              }
            })
          }
        })
      } finally {
        await session.endSession()
      }
      return
    }
    if (req.params.name == 'card') {
      if (req.params.settings == 'create') {
        const payload = JSON.parse(req.body.payload)
        const session = await mongoose.connection.startSession()
        const opts = { session }
        try {
          await session.withTransaction(async () => {
            let docs = []
            payload.cards.forEach((val) => {
              docs.push({
                auid: req.auid,
                product: payload.product,
                type: payload.type,
                value: encrypt(val),
                bnote: payload.bnote,
                bprice: payload.bprice,
              })
            })
            let test = await card.insertMany(docs, opts)
            await product
              .updateOne(
                { _id: payload.product },
                {
                  $inc: {
                    'types.$[elem].tot': test.length,
                  },
                },
                { arrayFilters: [{ 'elem._id': payload.type }] }
              )
              .session(session)
            let added = []
            test.forEach((el) => {
              added.push(decrypt(el.value))
            })
            res.json({ done: true, added: added })
          })
        } finally {
          await session.endSession()
        }
      } else if (req.params.settings == 'del') {
        const payload = JSON.parse(req.body.payload)
        const session = await mongoose.connection.startSession()
        try {
          await session.withTransaction(async () => {
            let result = await card
              .deleteOne({ _id: req.body.id })
              .session(session)
            let sold = payload.sold ? -1 : 0
            if (result.deletedCount) {
              await product
                .updateOne(
                  { _id: payload.product },
                  {
                    $inc: {
                      'types.$[elem].tot': -1,
                      'types.$[elem].cur': sold,
                    },
                  },
                  { arrayFilters: [{ 'elem._id': payload.type }] }
                )
                .session(session)
            }
            res.json({ done: true })
          })
        } finally {
          await session.endSession()
        }
      } else if (req.params.settings == 'delsold') {
        const payload = JSON.parse(req.body.payload)
        const session = await mongoose.connection.startSession()
        try {
          await session.withTransaction(async () => {
            let result = await card
              .deleteMany({
                product: payload.product,
                type: payload.type,
                sold: true,
              })
              .session(session)
            await product
              .updateOne(
                { _id: payload.product },
                {
                  $inc: {
                    'types.$[elem].tot': -result.deletedCount,
                    'types.$[elem].cur': -result.deletedCount,
                  },
                },
                { arrayFilters: [{ 'elem._id': payload.type }] }
              )
              .session(session)
            res.json({ done: true })
          })
        } finally {
          await session.endSession()
        }
      } else {
        throw new Error('404 - admins - card')
      }
      return
    }
    if (req.params.name == 'serreq') {
      if (req.params.settings == 'deny') {
        const payload = JSON.parse(req.body.payload)
        let ser = await ServiceReq.findByIdAndUpdate(
          req.body.id,
          {
            status: 'DA',
            $push: {
              res: {
                auid: 'Admin :' + req.auid,
                rtype: 'Denied',
                time: Date.now(),
                note: payload.note,
              },
            },
          },
          {
            uid: 1,
          }
        ).lean()
        let duser = await User.findOne(
          { uid: ser.uid },
          { fcmtokens: 1 }
        ).lean()
        await UNotify(
          duser.fcmtokens,
          'Service Request Denied',
          'Sorry, but Service Reques ' + ser._id.toString() + ' was denied',
          'negative',
          ser._id.toString(),
          '/service/' + ser._id.toString()
        )
        res.json({ done: true })
      }
      if (req.params.settings == 'resp') {
        const payload = JSON.parse(req.body.payload)
        let ser = await ServiceReq.findByIdAndUpdate(
          req.body.id,
          {
            $push: {
              res: {
                auid: 'Admin :' + req.auid,
                rtype: 'Message',
                time: Date.now(),
                note: payload.note,
              },
            },
          },
          {
            uid: 1,
          }
        ).lean()
        let duser = await User.findOne(
          { uid: ser.uid },
          { fcmtokens: 1 }
        ).lean()
        await UNotify(
          duser.fcmtokens,
          'Service Request Message',
          'Service Request ' + ser._id.toString() + ' has a new Message',
          'info',
          ser._id.toString(),
          '/service/' + ser._id.toString()
        )
        res.json({ done: true })
      }
      if (req.params.settings == 'end') {
        const payload = JSON.parse(req.body.payload)
        let ser = await ServiceReq.findByIdAndUpdate(
          req.body.id,
          {
            status: 'HA',
            $push: {
              res: {
                auid: 'Admin :' + req.auid,
                rtype: 'Fullfilled',
                time: Date.now(),
                note: payload.note,
              },
            },
          },
          {
            uid: 1,
          }
        ).lean()
        let duser = await User.findOne(
          { uid: ser.uid },
          { fcmtokens: 1 }
        ).lean()
        await UNotify(
          duser.fcmtokens,
          'Service Request Fullfilled',
          'Service Request ' + ser._id.toString() + ' was Fullfilled',
          'positive',
          ser._id.toString(),
          '/service/' + ser._id.toString()
        )
        res.json({ done: true })
      }
      if (req.params.settings == 'price') {
        const payload = JSON.parse(req.body.payload)
        let ser = await ServiceReq.findByIdAndUpdate(
          req.body.id,
          {
            status: 'PU',
            price: payload.price,
            bprice: payload.bprice,
            $push: {
              res: {
                auid: 'Admin :' + req.auid,
                rtype: 'Price',
                time: Date.now(),
                note: payload.note,
              },
            },
          },
          {
            uid: 1,
          }
        ).lean()
        let duser = await User.findOne(
          { uid: ser.uid },
          { fcmtokens: 1 }
        ).lean()
        await UNotify(
          duser.fcmtokens,
          'Service Request Offer',
          'The price for this service ' +
            ser._id.toString() +
            ' was set by admin , Accept or Deny',
          'warning',
          ser._id.toString(),
          '/service/' + ser._id.toString()
        )
        res.json({ done: true })
      }
      if (req.params.settings == 'handle') {
        const payload = JSON.parse(req.body.payload)
        const session = await mongoose.connection.startSession()
        try {
          await session.withTransaction(async () => {
            let ser = await ServiceReq.findByIdAndUpdate(
              req.body.id,
              {
                status: 'HH',
                $push: {
                  res: {
                    auid: req.auid,
                    rtype: 'Handling',
                    time: Date.now(),
                    note: payload.note,
                  },
                },
              },
              {
                uid: 1,
                price: 1,
                bprice: 1,
              }
            )
              .lean()
              .session(session)
            let today = new Date()
            today = today.setHours(0, 0, 0, 0)
            await Daily.updateOne(
              {
                time: today,
                product: 'SERVICE',
                type: ser.tdata.productname.en,
              },
              {
                $inc: {
                  snum: 1,
                  i: ser.price,
                  o: ser.bprice,
                },
              },
              {
                upsert: true,
              }
            ).session(session)
            await Daily.updateOne(
              { time: today, product: 'ALL', type: 'ALL' },
              {
                $inc: {
                  snum: 1,
                  i: ser.price,
                  o: ser.bprice,
                },
              },
              {
                upsert: true,
              }
            ).session(session)
            let duser = await User.findOneAndUpdate(
              { uid: ser.uid },
              {
                $inc: {
                  money: -ser.price,
                },
              },
              {
                fcmtokens: 1,
              }
            )
              .lean()
              .session(session)
            if (duser.money < ser.price) {
              await UNotify(
                duser.fcmtokens,
                'TopUp required',
                'Your balance is too low for this service ' +
                  ser._id.toString(),
                'negative',
                ser._id.toString(),
                '/service/' + ser._id.toString()
              )
              throw new Error('No Money !! cancled before ??')
            }
            await UNotify(
              duser.fcmtokens,
              'Service Request Handling',
              'Your service Request' + ser._id.toString() + ' is being handled',
              'positive',
              ser._id.toString(),
              '/service/' + ser._id.toString()
            )
            res.json({ done: true })
          })
        } finally {
          await session.endSession()
        }
      }
      return
    }
    let model
    let notify = false
    let image = false
    if (req.params.name == 'news') {
      model = news
      notify = true
    } else if (req.params.name == 'slide') {
      notify = true
      image = true
      model = slide
    } else if (req.params.name == 'product') {
      image = true
      model = product
    } else if (req.params.name == 'service') {
      image = true
      model = service
    } else if (req.params.name == 'category') {
      image = true
      model = category
    } else if (req.params.name == 'cards') {
      image = false
      model = card
    } else if (req.params.name == 'User') {
      model = User
    } else if (req.params.name == 'Activity') {
      model = Activity
    } else if (req.params.name == 'Method') {
      model = Method
    } else if (req.params.name == 'security') {
      model = Slog
    } else if (req.params.name == 'Discount') {
      model = Discount
    } else {
      throw new Error('404 - Bad Model call')
    }
    let body = JSON.parse(req.body.payload)
    body.auid = req.auid
    if (image) {
      // admin uploader
      for (let index = 0; index < req.files.length; index++) {
        await jwtClient.authorize()
        let fileMetadata
        fileMetadata = {
          name:
            req.params.name +
            '-' +
            req.params.settings +
            '-' +
            req.decodedToken.uid,
          parents: ['1SYsmPhitpxd_os1j_U-d72onzMGmZgVx'],
        }
        const media = {
          mimeType: req.files[index].mime,
          body: req.files[index].pass,
        }
        let data = await drive.files.create({
          auth: jwtClient,
          resource: fileMetadata,
          media,
          fields: 'id',
        })
        await drive.permissions.create({
          auth: jwtClient,
          fileId: data.data.id,
          resource: {
            type: 'anyone',
            role: 'reader',
          },
        })
        req.uploaded.push(data.data.id)
        Flog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          name: req.files[0].name,
          filename: req.files[0].filename,
          mime: req.files[0].mime,
          id: data.data.id,
        })
      }
      // admin uploader
    }

    if (req.uploaded.length) {
      body.image =
        'https://drive.google.com/uc?export=view&id=' + req.uploaded[0]
    }
    if (req.params.settings == 'create') {
      await model.create(body)
      if (notify) {
        await NewsNotify(body.title, body.text)
      }
    } else if (req.params.settings == 'update') {
      if (req.uploaded.length) {
        let old = await model.findByIdAndUpdate({ _id: req.body.id }, body)
        try {
          await drive.files.delete({
            auth: jwtClient,
            fileId: old.image.split('id=')[1],
          })
        } catch (er) {
          logger.error(er)
        }
      } else {
        await model.updateOne({ _id: req.body.id }, body)
      }

      if (notify) {
        await NewsNotify(body.title, body.text)
      }
    } else if (req.params.settings == 'delete') {
      if (req.params.name == 'product') {
        await card.deleteMany({ product: req.body.id })
      }
      if (image) {
        let old = await model.findByIdAndDelete({ _id: req.body.id })
        try {
          await drive.files.delete({
            auth: jwtClient,
            fileId: old.image.split('id=')[1],
          })
        } catch (er) {
          logger.error(er)
        }
      } else {
        await model.deleteOne({ _id: req.body.id })
      }
    } else if (req.params.settings == 'security') {
      let slog = await model.findByIdAndUpdate(
        { _id: req.body.id },
        {
          handle: {
            ban: body.ban,
            auid: body.auid,
            note: body.note,
            time: Date.now(),
          },
          handled: true,
        }
      )
      if (body.ban) {
        await admin.auth().updateUser(slog.uid, {
          disabled: true,
        })
        await User.findOneAndUpdate(
          { uid: slog.uid },
          {
            flaged: true,
            flagenote: 'Banned due to security ' + req.body.id,
          }
        )
      }
    } else {
      throw new Error('404 - Bad Settings call')
    }
    res.json({
      done: true,
    })
  } catch (err) {
    try {
      if (req.uploaded) {
        req.uploaded.forEach(async (element) => {
          try {
            await drive.files.delete({
              auth: jwtClient,
              fileId: element,
            })
          } catch (er) {
            logger.error(er)
          }
        })
      }
      const slog = await Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Admin',
        message: err.message,
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } catch (err) {
      logger.error(err, ' error not loged ')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  }
}
