const logger = require('pino')()
const { Slog, Flog } = require('../models/Logs')
const User = require('../models/User')
const NotifyAdmins = require('../utils/nota')
const UNotify = require('../utils/notu')
const Activity = require('../models/Activity')
const { product, service } = require('../models/Category')
const Order = require('../models/Order')
const ServiceReq = require('../models/ServiceReq')
const Wallet = require('../models/Wallet')
const TopUp = require('../models/TopUp')
const fullfill = require('../utils/fullfill')
const admin = require('firebase-admin')
const mongoose = require('mongoose')
const { google } = require('googleapis')
const key = require('../config/gdrive.json')
const drive = google.drive('v3')
const jwtClient = new google.auth.JWT(
  key.client_email,
  null,
  key.private_key,
  ['https://www.googleapis.com/auth/drive'],
  null
)

module.exports = async function fb(req, res) {
  try {
    if (req.params.name == 'serreq') {
      if (req.params.settings == 'deny') {
        const payload = JSON.parse(req.body.payload)
        let ser = await ServiceReq.findOne({
          _id: req.body.id,
          uid: req.decodedToken.uid,
        })
        if (!ser) {
          throw new Error('NOT HIS SERVICE')
        }
        if (ser.status !== 'AU' && ser.status !== 'PU' && ser.status !== 'PA') {
          throw new Error('Canceling a service that being handled')
        }
        await ServiceReq.findOneAndUpdate(
          { _id: req.body.id, uid: req.decodedToken.uid },
          {
            status: 'DU',
            $push: {
              res: {
                auid: 'User',
                rtype: 'Cancel',
                time: Date.now(),
                note: payload.note,
              },
            },
          }
        ).lean()
        NotifyAdmins(
          'Service Request Canceled',
          'Service Request ' + ser._id.toString() + ' was Canceled',
          'info',
          ser._id.toString(),
          '/admin-serreq/' + ser._id.toString()
        )
        res.json({ done: true })
      }
      if (req.params.settings == 'resp') {
        const payload = JSON.parse(req.body.payload)
        let ser = await ServiceReq.findOne({
          _id: req.body.id,
          uid: req.decodedToken.uid,
        })
        if (!ser) {
          throw new Error('NOT HIS SERVICE')
        }
        if (ser.status == 'DU' || ser.status == 'DA' || ser.status == 'HA') {
          throw new Error('message to a service that is ' + ser.status)
        }
        await ServiceReq.findOneAndUpdate(
          { _id: req.body.id, uid: req.decodedToken.uid },
          {
            $push: {
              res: {
                auid: 'User',
                rtype: 'Message',
                time: Date.now(),
                note: payload.note,
              },
            },
          }
        ).lean()
        await NotifyAdmins(
          'Service Request Message',
          'Service Request ' + ser._id.toString() + ' has a new Message',
          'info',
          ser._id.toString(),
          '/admin-serreq/' + ser._id.toString()
        )
        res.json({ done: true })
      }
      if (req.params.settings == 'price') {
        const payload = JSON.parse(req.body.payload)
        let ser = await ServiceReq.findOne({
          _id: req.body.id,
          uid: req.decodedToken.uid,
        })
        if (!ser) {
          throw new Error('NOT HIS SERVICE')
        }
        if (ser.status !== 'PU') {
          throw new Error('message to a service that is ' + ser.status)
        }
        await ServiceReq.findOneAndUpdate(
          { _id: req.body.id, uid: req.decodedToken.uid },
          {
            status: 'AU',
            $push: {
              res: {
                auid: 'User',
                rtype: 'Accept',
                time: Date.now(),
                note: payload.note,
              },
            },
          }
        ).lean()
        await NotifyAdmins(
          'Service Request Message',
          'Service Request ' + ser._id.toString() + ' was Accepted',
          'warning',
          ser._id.toString(),
          '/admin-serreq/' + ser._id.toString()
        )
        res.json({ done: true })
      }
    } else if (req.params.name == 'srequest') {
      const payload = JSON.parse(req.body.payload)
      const ser = await service
        .findOne({ _id: payload.service }, { image: 1, title: 1 })
        .lean()
      if (!ser) {
        throw new Error('he faked the service :/')
      }
      const tdata = {
        productname: ser.title,
        productimg: ser.image,
      }
      const reqs = await ServiceReq.create({
        uid: req.decodedToken.uid,
        status: 'PA',
        reqfields: payload.reqfields,
        product: payload.service,
        tdata: tdata,
      })
      await NotifyAdmins(
        'Service - New Service Request',
        ser.title.en + ' - Id: ' + reqs._id,
        'warning',
        'ID' + reqs._id,
        '/admin-serreq/' + reqs._id
      )
      res.json({ done: true, added: reqs._id.toString() })
    } else if (req.params.name == 'setused') {
      if (!req.body.usedcard) {
        req.body.usedcard = []
      } else {
        req.body.usedcard = JSON.parse(req.body.usedcard)
      }
      await Order.updateOne(
        {
          _id: req.body.id,
          uid: req.decodedToken.uid,
        },
        {
          usedcards: req.body.usedcard,
        }
      )
      res.json({ done: true })
    } else if (req.params.name == 'notification') {
      if (!req.body.plat || !req.body.lang || !req.body.currentToken) {
        throw new Error('notification bad')
      }
      let duser = await User.findOne({ uid: req.decodedToken.uid })
      if (duser.fcmtokens[req.body.plat]) {
        await admin
          .messaging()
          .unsubscribeFromTopic(duser.fcmtokens[req.body.plat], 'news-en')
        await admin
          .messaging()
          .unsubscribeFromTopic(duser.fcmtokens[req.body.plat], 'news-ar')
        await admin
          .messaging()
          .unsubscribeFromTopic(duser.fcmtokens[req.body.plat], 'news-fr')
      }
      duser.fcmtokens.lang = req.body.lang
      duser.fcmtokens[req.body.plat] = req.body.currentToken
      duser.fcmtokens.account = req.body.data.includes('account')
      duser.fcmtokens.messages = req.body.data.includes('messages')
      duser.fcmtokens.news = req.body.data.includes('news')
      if (req.body.data.includes('news')) {
        await admin
          .messaging()
          .subscribeToTopic(req.body.currentToken, 'news' + '-' + req.body.lang)
      }
      await duser.save()
      Activity.create({
        uid: req.decodedToken.uid,
        type: 'Auth',
        ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ua: req.headers['user-agent'],
        description: 'UNS',
      })
      let tos = duser.toObject()
      res.json({ done: true, duser: tos })
    } else if (req.params.name == 'topup') {
      // uploader
      let proof = []
      for (let index = 0; index < req.files.length; index++) {
        await jwtClient.authorize()
        let fileMetadata
        if (req.files[index].name == 'ident') {
          fileMetadata = {
            name: req.body.id + '-' + req.decodedToken.uid,
            parents: ['1dLt7CNINS0L7hH82WYbTLZ5qgUnCIEnx'],
          }
        } else if (req.files[index].name == 'pv') {
          fileMetadata = {
            name: req.body.id + '-' + req.decodedToken.uid,
            parents: ['1ttRTb_-oyOqyaxKNtIK4Z39663f-qMWI'],
          }
        } else if (req.files[index].name == 'proof') {
          fileMetadata = {
            name: req.body.id + '-' + req.decodedToken.uid,
            parents: ['1cz-zUUNCVPznEbuIkeBMLUzSESAvhYO5'],
          }
        } else {
          throw new Error('Possible  Request Tampe')
        }
        const media = {
          mimeType: req.files[index].mime,
          body: req.files[index].pass,
        }
        let data = await drive.files.create({
          auth: jwtClient,
          resource: fileMetadata,
          media,
          fields: 'id',
        })
        await drive.permissions.create({
          auth: jwtClient,
          fileId: data.data.id,
          resource: {
            type: 'anyone',
            role: 'reader',
          },
        })
        let link = await drive.files.get({
          auth: jwtClient,
          fileId: data.data.id,
          fields: 'thumbnailLink',
        })
        if (!link.data.thumbnailLink) {
          const slog = new Slog({
            aid: req.alogid,
            uid: req.decodedToken.uid,
            type: 'uploadRoute',
            errorobj:
              req.files[0].filename + req.files[0].name + req.files[0].mime,
            message: 'Possible Bypass - Fileid: ' + data.data.id,
          })
          await slog.save()
        }
        proof.push({
          name: req.files[index].name,
          filename: req.files[index].filename,
          thumb: link.data.thumbnailLink,
          id: data.data.id,
        })
        req.uploaded.push(data.data.id)
        Flog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          name: req.files[index].name,
          filename: req.files[index].filename,
          mime: req.files[index].mime,
          id: data.data.id,
        })
      }
      // uploader
      if (req.params.settings == 'new') {
        if (!req.body.method || !req.body.amount) {
          throw new Error('topup bad')
        }
        const session = await mongoose.connection.startSession()
        const opts = { session }
        try {
          await session.withTransaction(async () => {
            let aTopUp = await TopUp.create(
              [
                {
                  uid: req.decodedToken.uid,
                  status: 'WP',
                  method: req.body.method,
                  amount: req.body.amount,
                },
              ],
              opts
            )
            await Wallet.findOneAndUpdate(
              { _id: '123456789012345678901234' },
              {
                $inc: { totpt: 1 },
              },
              {
                new: true,
                upsert: true, // Make this update into an upsert
              }
            )
              .session(session)
              .lean()
            let user = await User.findOneAndUpdate(
              { uid: req.decodedToken.uid },
              { $inc: { 'userstats.pt': 1 } }
            )
              .lean()
              .session(session)
            await Activity.create(
              [
                {
                  uid: req.decodedToken.uid,
                  type: 'TopUp',
                  ip:
                    req.headers['x-forwarded-for'] ||
                    req.connection.remoteAddress,
                  ua: req.headers['user-agent'],
                  description: 'PT',
                  params: [aTopUp[0]._id, req.body.method, req.body.amount],
                },
              ],
              opts
            )
            res.json({ done: true, TopUp: aTopUp[0].toObject(), user })

            await NotifyAdmins(
              'New TopUp Request',
              user.fullName + ' - Id: ' + aTopUp[0]._id,
              'info',
              'ID' + aTopUp[0]._id,
              'nourl'
            )
          })
        } finally {
          await session.endSession()
        }
      } else if (req.params.settings == 'lend') {
        if (req.files.length < 2 || !req.body.id) {
          throw new Error('bad lend req')
        }
        const session = await mongoose.connection.startSession()
        let aTopUp
        let user
        try {
          await session.withTransaction(async () => {
            const opts = { session }
            aTopUp = await TopUp.findByIdAndUpdate(
              req.body.id,
              {
                status: 'WAB',
                $push: { proof: proof },
              },
              opts
            )
            if (aTopUp.uid !== req.decodedToken.uid) {
              throw new Error(
                'Useless Attempt to Hijack topup of ' + aTopUp.uid
              )
            }
            if (aTopUp.status !== 'WP') {
              throw new Error('Attempted to clear proof / or double req ')
            }
            aTopUp.status = 'WAB'
            user = await User.findOne({ uid: req.decodedToken.uid })
              .session(session)
              .lean()
            if (user.flagged) {
              throw new Error('User is flagged')
            }
            await Activity.create(
              [
                {
                  uid: req.decodedToken.uid,
                  type: 'TopUp',
                  ip:
                    req.headers['x-forwarded-for'] ||
                    req.connection.remoteAddress,
                  ua: req.headers['user-agent'],
                  description: 'PBR',
                  params: [aTopUp._id, aTopUp.method, aTopUp.amount],
                },
              ],
              session
            )
            await NotifyAdmins(
              'TopUp Lending Request',
              user.fullName + ' - Id: ' + aTopUp._id,
              'warning',
              'ID' + aTopUp._id,
              '/admin-topup/' + aTopUp._id
            )
            res.json({
              done: true,
              TopUp: aTopUp.toObject(),
              user,
            })
          })
        } finally {
          await session.endSession()
        }
      } else if (req.params.settings == 'proof') {
        if (req.files.length < 1 || !req.body.id) {
          throw new Error('bad lend req')
        }
        const session = await mongoose.connection.startSession()
        let aTopUp
        let user
        try {
          await session.withTransaction(async () => {
            const opts = { session }
            aTopUp = await TopUp.findByIdAndUpdate(
              req.body.id,
              {
                status: 'WAP',
                $push: { proof: proof },
              },
              opts
            )
            if (aTopUp.uid !== req.decodedToken.uid) {
              throw new Error(
                'Useless Attempt to Hijack topup of ' + aTopUp.uid
              )
            }
            if (aTopUp.status !== 'WP') {
              if (aTopUp.status !== 'B') {
                throw new Error('Attempted to clear proof / or double req ')
              }
            }
            aTopUp.status = 'WAP'
            user = await User.findOne({ uid: req.decodedToken.uid }).session(
              session
            )
            if (user.flagged) {
              throw new Error('User is flagged')
            }
            await Activity.create(
              [
                {
                  uid: req.decodedToken.uid,
                  type: 'TopUp',
                  ip:
                    req.headers['x-forwarded-for'] ||
                    req.connection.remoteAddress,
                  ua: req.headers['user-agent'],
                  description: 'PP',
                  params: [aTopUp._id, aTopUp.method, aTopUp.amount],
                },
              ],
              session
            )
            await NotifyAdmins(
              'TopUp - Payment Request',
              user.fullName + ' - Id: ' + aTopUp._id,
              'warning',
              'ID' + aTopUp._id,
              '/admin-topup/' + aTopUp._id
            )
            res.json({
              done: true,
              TopUp: aTopUp.toObject(),
              user,
            })
          })
        } finally {
          await session.endSession()
        }
      } else if (req.params.settings == 'cancel') {
        const session = await mongoose.connection.startSession()
        let aTopUp
        let user
        try {
          await session.withTransaction(async () => {
            await Wallet.updateOne(
              { _id: '123456789012345678901234' },
              {
                $inc: { totpt: -1 },
              },
              {
                new: true,
                upsert: true, // Make this update into an upsert
              }
            ).session(session)
            const opts = { session }
            aTopUp = await TopUp.findByIdAndUpdate(
              req.body.id,
              {
                status: 'C',
              },
              opts
            )
            if (aTopUp.uid !== req.decodedToken.uid) {
              throw new Error(
                'Useless Attempt to Hijack topup of ' + aTopUp.uid
              )
            }
            if (aTopUp.borrowed) {
              throw new Error('ATTEMPTED TO CANCEL A BORROW')
            }
            if (
              aTopUp.status == 'A' ||
              aTopUp.status == 'D' ||
              aTopUp.status == 'C' ||
              aTopUp.status == 'B'
            ) {
              throw new Error(
                'Attempted to cancel topup with statue of ' + aTopUp.status
              )
            }
            if (aTopUp.borrowed) {
              throw new Error('Attempted to cancel a borrowed topup !!!!!! ')
            }
            aTopUp.status = 'C'
            user = await User.findOneAndUpdate(
              { uid: req.decodedToken.uid },
              { $inc: { 'userstats.pt': -1, 'userstats.ct': 1 } },
              { session, new: true }
            ).lean()
            if (user.flaged) {
              throw new Error('User is flagged')
            }
            Activity.create({
              uid: req.decodedToken.uid,
              type: 'TopUp',
              ip:
                req.headers['x-forwarded-for'] || req.connection.remoteAddress,
              ua: req.headers['user-agent'],
              description: 'TC',
              params: [aTopUp._id, aTopUp.method, aTopUp.amount],
            })
            if (aTopUp.proof && aTopUp.proof.length) {
              aTopUp.proof.forEach((element) => {
                try {
                  drive.files.delete({
                    auth: jwtClient,
                    fileId: element.id,
                  })
                } catch (er) {
                  console.log(er)
                }
              })
            }
            res.json({
              done: true,
              TopUp: aTopUp.toObject(),
              user,
            })
            await NotifyAdmins(
              'TopUp Canceled',
              user.fullName + ' - Id: ' + aTopUp._id,
              'info',
              'ID' + aTopUp._id,
              'nourl'
            )
          })
        } finally {
          await session.endSession()
        }
      } else {
        throw new Error('404 - TopUp')
      }
    } else if (req.params.name == 'order') {
      const session = await mongoose.connection.startSession()
      const opts = { session }
      let testid = false
      try {
        await session.withTransaction(async () => {
          testid = false
          let user = await User.findOne(
            { uid: req.decodedToken.uid },
            { money: 1, discount: 1 },
            opts
          ).lean()
          let prod = await product
            .findOne(
              { _id: req.body.pid },
              {
                title: 1,
                image: 1,
                types: {
                  $elemMatch: { _id: req.body.tid },
                },
              },
              opts
            )
            .lean()
          if (!prod) {
            throw new Error('Aye No Product with this ID :/')
          }
          if (!prod.types) {
            throw new Error('Aye No Type with this ID :/')
          }
          // founding Price plan
          let best = 'lala'
          if (prod.types[0].prices) {
            prod.types[0].prices.forEach((element) => {
              if (user.discount === element.level) {
                best = element
              } else {
                if (best == 'lala' && element.level < user.discount) {
                  best = element
                }
                if (best < element.level && element.level < user.discount) {
                  best = element
                }
              }
            })
            if (best == 'lala') {
              throw new Error(
                'Aye Coudlnt find the best price for this dude :/ '
              )
            }
            if (!best.qt) {
              throw new Error('Aye there is no qt prices yet ')
            }
          } else {
            throw new Error('Aye No Prices was set for this prod yet')
          }
          // checking if qt is valid
          const n1 = Math.abs(req.body.qt)
          const n2 = parseInt(req.body.qt, 10)
          if (!isNaN(n1) && n2 === n1 && n1.toString() === req.body.qt) {
            // ANSANI
          } else {
            throw new Error('Aye Not a Natural Number for quantity')
          }
          // founding Price for qt
          let sprice = 0
          best.qt.forEach((element) => {
            if (parseInt(req.body.qt) >= element.q) {
              if (!sprice) {
                sprice = element
              } else if (sprice.p > element.p) {
                sprice = element
              }
            }
          })
          let amount = parseInt(sprice.p * parseInt(req.body.qt))
          let ptstd = parseInt(sprice.ps * parseInt(req.body.qt))
          // alright let get down to buisness
          user = await User.findOneAndUpdate(
            { uid: req.decodedToken.uid },
            {
              $inc: {
                'userstats.totm': amount,
                'userstats.po': 1,
                'userstats.toto': 1,
                money: -amount,
                pts: ptstd,
              },
            },
            opts
          ).lean()
          if (user.money < amount) {
            throw new Error('Aye ya3tih mahna xD , bgha yasra9')
          }
          let aOrder = await Order.create(
            [
              {
                uid: req.decodedToken.uid,
                status: 'NH',
                cards: [],
                product: req.body.pid,
                type: req.body.tid,
                tdata: {
                  typename: prod.types[0].name,
                  productname: prod.title,
                  productimg: prod.image,
                },
                qt: req.body.qt,
                sprice: sprice,
              },
            ],
            opts
          )
          await Activity.create(
            [
              {
                uid: req.decodedToken.uid,
                type: 'Order',
                ip:
                  req.headers['x-forwarded-for'] ||
                  req.connection.remoteAddress,
                ua: req.headers['user-agent'],
                description: 'PO',
                params: [
                  aOrder[0]._id.toString(),
                  req.body.qt,
                  prod.title.en,
                  prod.types[0].name,
                ],
              },
            ],
            opts
          )
          await NotifyAdmins(
            'New Order Placed',
            user.fullName + ' - Id: ' + aOrder[0]._id,
            'info',
            'ID' + aOrder[0]._id,
            'nourl'
          )
          await UNotify(
            user.fcmtokens,
            'Order Placed',
            'Order ' + aOrder[0]._id.toString() + ' was Placed',
            'positive',
            aOrder[0]._id.toString(),
            'nourl'
          )
          res.json({ done: true, order: aOrder[0] })
          testid = aOrder[0]._id
        })
      } catch (error) {
        testid = false
        throw new Error(error)
      } finally {
        await session.endSession()
        if (testid) {
          await fullfill(testid)
        }
      }
    } else if (req.params.name == 'corder') {
      const session = await mongoose.connection.startSession()
      const opts = { session }
      try {
        const aOrder = await Order.findOneAndUpdate(
          { _id: req.body.id },
          { handling: true }
        )
        if (!aOrder) {
          throw new Error('No order with this ID')
        }
        if (aOrder.status == 'FF') {
          throw new Error('Fullfiled ORDER')
        }
        if (aOrder.cards && aOrder.cards.length == aOrder.qt) {
          throw new Error('Fullfiled ORDER')
        }
        if (aOrder.status == 'C') {
          throw new Error('CANCELED ORDER')
        }
        if (aOrder.uid !== req.decodedToken.uid) {
          throw new Error('XD HE WANT TO CANCEL OTHERS ORDER ' + aOrder.uid)
        }
        if (aOrder.handling) {
          throw new Error('Being Handled')
        }
        await session.withTransaction(async () => {
          const aOrder = await Order.findOne({ _id: req.body.id }, null, opts)
          let sprice = aOrder.sprice
          let refqt = aOrder.qt
          if (aOrder.cards.length) {
            refqt = aOrder.qt - aOrder.cards.length
          }
          // founding Price for qt
          let amount = parseInt(sprice.p * parseInt(refqt))
          let ptstd = parseInt(sprice.ps * parseInt(refqt))
          // alright let get down to buisness
          const aOrder2 = await Order.findOneAndUpdate(
            { _id: req.body.id },
            {
              status: 'C',
            },
            opts
          ).lean()
          if (aOrder2.status == 'FF') {
            throw new Error('Fullfiled ORDER')
          }
          if (aOrder2.cards == aOrder2.card) {
            throw new Error('CHANGED cards')
          }
          await Wallet.updateOne(
            { _id: '123456789012345678901234' },
            {
              $inc: { totpo: -1 },
            },
            {
              new: true,
              upsert: true, // Make this update into an upsert
            }
          ).session(session)
          await product
            .updateOne(
              { _id: aOrder.product },
              {
                $inc: {
                  'types.$[elem].needed': -refqt,
                },
              },
              { arrayFilters: [{ 'elem._id': aOrder.type }] }
            )
            .session(session)
          let user = await User.findOneAndUpdate(
            { uid: aOrder.uid },
            {
              $inc: {
                'userstats.totm': -amount,
                'userstats.po': -1,
                'userstats.co': 1,
                money: amount,
                pts: -ptstd,
              },
            },
            opts
          ).lean()
          await Activity.create(
            [
              {
                uid: req.decodedToken.uid,
                type: 'Order',
                ip:
                  req.headers['x-forwarded-for'] ||
                  req.connection.remoteAddress,
                ua: req.headers['user-agent'],
                description: 'C',
                params: [
                  aOrder._id.toString(),
                  aOrder.qt,
                  aOrder.tdata.productname.en,
                  aOrder.tdata.typename,
                ],
              },
            ],
            opts
          )
          await UNotify(
            user.fcmtokens,
            'Order Canceled',
            'Order ' + aOrder._id.toString() + ' was Canceled',
            'positive',
            aOrder._id.toString(),
            'nourl'
          )
          await NotifyAdmins(
            'Order Canceled ' + aOrder._id,
            aOrder.tdata.productname.en + ' - ' + aOrder.tdata.typename,
            'info',
            aOrder.tdata.productname.en + aOrder._id,
            'nourl'
          )
          res.json({ done: true })
        })
      } catch (error) {
        throw new Error(error)
      } finally {
        await session.endSession()
        await Order.findOneAndUpdate({ _id: req.body.id }, { handling: false })
      }
      return
    } else {
      throw new Error('404')
    }
  } catch (err) {
    try {
      if (req.uploaded) {
        try {
          req.uploaded.forEach(async (element) => {
            await drive.files.delete({
              auth: jwtClient,
              fileId: element,
            })
          })
        } catch (er) {
          logger.error(er)
        }
      }
      const slog = await Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Set',
        message: err.message,
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } catch (err) {
      logger.error(err, ' error not loged ')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  }
}
