const logger = require('pino')()
const { Slog } = require('../models/Logs')
const formidable = require('formidable')
const { PassThrough } = require('stream')
const maxsize = 1024 * 1024 * 5
const totsize = 1024 * 1024 * 5 * 4

module.exports = async function (req, res, next) {
  req.files = []
  req.fileserr = []
  req.uploaded = []
  const form = new formidable.IncomingForm()
  let tsize = 0
  form.onPart = function (part) {
    try {
      if (!part.filename) {
        form.handlePart(part)
        return
      }
      let pass = new PassThrough()
      let size = 0
      let skip = false
      part.on('data', function (buffer) {
        if (skip) {
          return
        }
        size += buffer.length
        tsize += buffer.length
        if (size > maxsize) {
          skip = true
          pass.end()
          pass.destroy()
          req.fileserr.push({
            aid: req.alogid,
            uid: req.decodedToken.uid,
            name: part.name,
            filename: part.filename,
            mime: part.mime,
            err: 'Max Size bypass',
          })
          // res.end('bye')
          req.destroy('bye')
          return
        }
        if (tsize > totsize) {
          skip = true
          pass.end()
          pass.destroy()
          req.fileserr.push({
            aid: req.alogid,
            uid: req.decodedToken.uid,
            name: part.name,
            filename: part.filename,
            mime: part.mime,
            err: 'Tot Size bypass',
          })
          // res.end('bye')
          req.destroy('bye')
          return
        }
        pass.write(buffer)
        // console.log('data:' + buffer.length)
        // console.log(await FileType.fromBuffer(buffer))
        // console.log(buffer)
      })
      part.on('end', function () {
        if (skip) {
          return
        }
        pass.end()
        req.files.push({
          name: part.name,
          filename: part.filename,
          mime: part.mime,
          pass: pass,
        })
        // pass.destroy()
      })
    } catch (err) {
      form.emit('error', err)
    }
  }
  form.parse(req, async (err, fields) => {
    req.body = {}
    Object.keys(fields).forEach(function (key) {
      if (/\$/g.test(fields[key])) {
        fields[key].replace(/\$/g, '\uFF04')
        Slog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'Parser',
          message:
            'Possible Query injection at key ' + key + ' value ' + fields[key],
        })
      }
      req.body[key] = fields[key]
    })
    req.alogid.body = JSON.stringify(req.body)
    if (req.fileserr.length) {
      req.files = null
      try {
        const slog = new Slog({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'uploadRoute',
          errorobj: JSON.stringify(req.fileserr),
          message: 'Upload',
        })
        await slog.save()
        if (!res.writableEnded) {
          res.json({
            error: true,
            errmsg: 'Error ID: ' + slog._id,
          })
        }
      } catch (err) {
        logger.error(err, 'uploadRoute')
        if (!res.writableEnded) {
          res.json({
            error: true,
            errmsg: 'Error: Internal Error , Please try again Later',
          })
        }
      }
    } else if (req.files.length) {
      for (let index = 0; index < req.files.length; index++) {
        if (req.files[index].mime.split('/')[0] !== 'image') {
          req.files[index].pass = null
          const slog = new Slog({
            aid: req.alogid,
            uid: req.decodedToken.uid,
            type: 'uploadRoute',
            errorobj:
              req.files[index].filename +
              req.files[index].name +
              req.files[index].mime,
            message: 'Mime Bypass',
          })
          await slog.save()
          if (!res.writableEnded) {
            res.json({
              error: true,
              errmsg: 'Error ID: ' + slog._id,
            })
          }
        }
      }
      next()
    } else if (err) {
      try {
        const slog = await Slog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'Upload',
          errorobj: err ? err.message : 'IDK',
        })
        if (!res.writableEnded) {
          res.json({
            error: true,
            errmsg: 'Error ID: ' + slog._id,
          })
        }
      } catch (err) {
        logger.error(err, 'uploadRoute')
        if (!res.writableEnded) {
          res.json({
            error: true,
            errmsg: 'Error: Internal Error , Please try again Later',
          })
        }
      }
    } else {
      next()
    }
  })
}
