const logger = require('pino')()
const { Alog, Slog } = require('../models/Logs')
const User = require('../models/User')
const { news, slide } = require('../models/News')
const { category, product, card, service } = require('../models/Category')
const Activity = require('../models/Activity')
const TopUp = require('../models/TopUp')
const Order = require('../models/Order')
const Daily = require('../models/Daily')
const Wallet = require('../models/Wallet')
const { decrypt } = require('../utils/enc')
const serreq = require('../models/ServiceReq')
const AOrder = require('../models/AOrder')
const Method = require('../models/Method')
const Discount = require('../models/Discount')
const sanitizeHtml = require('sanitize-html')
const admin = require('../config/admins')
module.exports = async function fb(req, res) {
  Object.keys(req.query).forEach(function (key) {
    if (/\$/g.test(req.query[key])) {
      try {
        req.query[key].replace(/\$/g, '\uFF04')
        Slog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'Parser',
          message:
            'Possible Query injection at Querie ' +
            key +
            ' value ' +
            req.query[key],
        })
      } catch (error) {
        throw new Error(error.message)
      }
    }
    req.query[key].replace(/\$/g, '\uFF04').replace(/\./g, '\uFF0E')
    let old = req.query[key]
    req.query[key] = sanitizeHtml(req.query[key])
    if (old !== req.query[key]) {
      Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Parser',
        message: 'Possible XSS Attack at Querie ' + key + ' value ' + old,
      })
    }
  })
  Object.keys(req.params).forEach(function (key) {
    if (/\$/g.test(req.params[key])) {
      req.params[key].replace(/\$/g, '\uFF04')
      Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Parser',
        message:
          'Possible Query injection at params ' +
          key +
          ' value ' +
          req.params[key],
      })
    }
    req.params[key].replace(/\$/g, '\uFF04').replace(/\./g, '\uFF0E')
    let old = req.params[key]
    req.params[key] = sanitizeHtml(req.params[key])
    if (old !== req.params[key]) {
      Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Parser',
        message: 'Possible XSS Attack at key ' + key + ' value ' + old,
      })
    }
  })
  try {
    let model
    let uid = true
    let time = true
    let populate = false
    let adminonly = false
    let allowed = []
    if (req.params.name == 'news') {
      model = news
      uid = false
      time = false
      allowed = ['_id']
    } else if (req.params.name == 'slide') {
      model = slide
      uid = false
      time = false
      allowed = ['_id']
    } else if (req.params.name == 'product') {
      model = product
      uid = false
      time = false
      allowed = ['_id', 'category']
    } else if (req.params.name == 'service') {
      model = service
      uid = false
      time = false
      allowed = ['_id', 'category']
    } else if (req.params.name == 'AOrder') {
      adminonly = true
      model = AOrder
      uid = false
      time = false
      allowed = ['_id', 'auid', 'product', 'type']
    } else if (req.params.name == 'category') {
      model = category
      uid = false
      time = false
      allowed = ['_id']
    } else if (req.params.name == 'User') {
      model = User
      uid = true
      time = false
      allowed = ['phoneNumber', 'uid', '_id', 'fullName', 'flaged']
    } else if (req.params.name == 'Activity') {
      model = Activity
      uid = true
      time = true
      populate = true
      allowed = ['type', 'uid', '_id']
    } else if (req.params.name == 'TopUp') {
      model = TopUp
      uid = true
      time = true
      allowed = ['method', 'amount', '_id', 'status']
    } else if (req.params.name == 'order') {
      model = Order
      uid = true
      time = true
      allowed = ['product', 'type', '_id', 'status']
    } else if (req.params.name == 'porder') {
      model = Order
      uid = true
      time = true
      allowed = ['product', 'type', '_id', 'status']
    } else if (req.params.name == 'uorder') {
      model = Order
      uid = true
      time = true
      allowed = ['product', 'type', '_id', 'status']
    } else if (req.params.name == 'serreq') {
      model = serreq
      uid = true
      time = true
      allowed = ['tdata.productname.en', '_id', 'status']
    } else if (req.params.name == 'Method') {
      model = Method
      uid = false
      time = false
    } else if (req.params.name == 'Discount') {
      model = Discount
      uid = false
      time = false
    } else if (req.params.name == 'cards') {
      adminonly = true
      model = card
      uid = false
      time = false
      allowed = ['product', 'bnote', 'sorder', 'type', 'sold', '_id']
    } else if (req.params.name == 'Daily') {
      adminonly = true
      model = Daily
      uid = false
      time = false
      allowed = ['product']
    } else if (req.params.name == 'wallet') {
      adminonly = true
      model = Wallet
      uid = false
      time = false
      allowed = []
    } else if (req.params.name == 'Security') {
      populate = true
      adminonly = true
      model = Slog
      uid = true
      time = true
      allowed = ['type', 'handled', '_id']
    } else if (req.params.name == 'Logs') {
      adminonly = true
      populate = true
      model = Alog
      uid = true
      time = true
      allowed = ['method', '_id']
    } else {
      throw new Error('404 - No Bad Model call')
    }
    const set = req.params.settings.split('-')
    if (set.length !== 4) {
      throw new Error('Bad Req params ' + set)
    }
    const check = set.every(function (element) {
      return !isNaN(parseInt(element))
    })
    if (!check) {
      throw new Error('Bad Req params ' + set)
    }
    let query = {}
    const diff = parseInt(set[3]) - parseInt(set[2])
    if (diff == 0) {
      if (time) {
        throw new Error('Want No Limit on a time :/')
      }
    } else {
      const daysdiff = diff / 1000 / 60 / 60 / 24
      if (daysdiff > 10) {
        throw new Error('Want more then 10 days :/')
      }
      const td = new Date(parseInt(set[3]))
      td.setDate(td.getDate() + 1)
      let to = td.toISOString()
      let from = new Date(parseInt(set[2])).toISOString()
      query.time = {
        $gte: from,
        $lte: to,
      }
    }
    let limit = parseInt(set[1])
    let skip = parseInt(set[0])

    if (adminonly) {
      if (!admin(req.decodedToken.uid)) {
        throw new Error('TRYING TO ACCESS ADMIN RESOURCE')
      }
    }
    if (req.params.name == 'cards') {
      if (
        admin(req.decodedToken.uid) !== 'Islem' &&
        admin(req.decodedToken.uid) !== 'Ilyes' &&
        admin(req.decodedToken.uid) !== 'Zakaria'
      ) {
        res.json({
          row: [],
          count: 0,
        })
        return
      }
    }
    if (uid) {
      if (admin(req.decodedToken.uid)) {
        populate = true
        if (req.query.uid) {
          // admin dir wash thab tnakh xD
          query.uid = req.query.uid
        }
      } else {
        if (!req.query.uid) {
          throw new Error('Lol he try to get all users stuff xD')
        } else if (req.decodedToken.uid !== req.query.uid) {
          throw new Error(
            'this dude attempt ' +
              req.decodedToken.uid +
              ' to get this dude ' +
              req.query.uid
          )
        } else {
          query.uid = req.query.uid
        }
      }
    }
    let sort = { time: -1 }
    if (req.query.sort && req.query.assend) {
      sort = { [req.query.sort]: parseInt(req.query.assend) }
    }
    if (req.query.field) {
      if (allowed.includes(req.query.field)) {
        query[req.query.field] = req.query.value
      } else {
        throw new Error('the niga tried to set his field')
      }
    }
    if (req.query.field2) {
      if (allowed.includes(req.query.field2)) {
        query[req.query.field2] = req.query.value2
      } else {
        throw new Error('the niga tried to set his field')
      }
    }
    if (req.query.field3) {
      if (allowed.includes(req.query.field3)) {
        query[req.query.field3] = req.query.value3
      } else {
        throw new Error('the niga tried to set his field')
      }
    }
    if (req.params.name == 'porder') {
      query.status = { $in: ['PF', 'NF'] }
    }
    let count = await model.countDocuments(query).lean()
    let resp = await model.find(query).limit(limit).skip(skip).sort(sort).lean()
    if (req.params.name == 'cards') {
      let cache = {}
      for (let index = 0; index < resp.length; index++) {
        resp[index].value = decrypt(resp[index].value)
        const part = resp[index]
        if (cache[part.product] && cache[part.type]) {
          resp[index].pname = cache[part.product]
          resp[index].tname = cache[part.type]
        } else {
          let doc = await product
            .findOne(
              { _id: part.product },
              {
                image: 1,
                types: {
                  $elemMatch: { _id: part.type },
                },
              }
            )
            .lean()
          if (doc.types) {
            cache[part.product] = doc.image
            cache[part.type] = doc.types[0].name
            resp[index].pname = doc.image
            resp[index].tname = doc.types[0].name
          }
        }
      }
    }
    if (populate) {
      for (let index = 0; index < resp.length; index++) {
        const part = resp[index]
        if (part.uid) {
          let doc = await User.findOne(
            { uid: part.uid },
            {
              phoneNumber: 1,
              fullName: 1,
              image: 1,
              money: 1,
              userstats: 1,
            }
          ).lean()
          resp[index].phoneNumber = doc.phoneNumber
          resp[index].fullName = doc.fullName
          resp[index].image = doc.image
          resp[index].usermoney = doc.money
          resp[index].userstats = doc.userstats
        } else {
          resp[index].phoneNumber = 'N/A'
          resp[index].fullName = 'N/A'
          resp[index].image = './avatar.png'
          resp[index].userstats = {
            totm: 0,
            toto: 0,
            at: 0,
            ct: 0,
            dt: 0,
            po: 0,
            pt: 0,
          }
        }
      }
    }
    res.json({
      row: resp,
      count: count,
    })
  } catch (err) {
    try {
      const slog = await Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Get',
        message: err.message,
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } catch (err) {
      logger.error(err, ' error not loged ')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  }
}
