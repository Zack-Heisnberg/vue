const logger = require('pino')()
const { Slog } = require('../models/Logs')
const admin = require('../config/admins')
module.exports = async function fb(req, res, next) {
  if (!admin(req.decodedToken.uid)) {
    try {
      const slog = await Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Admin',
        message: 'THIS DUDE IS TRYING TO USE ADMIN API :o ( Ban him !!)',
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } catch (err) {
      logger.error(err, 'admin apu not logged ')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  } else {
    req.auid = admin(req.decodedToken.uid)
    next()
  }
}
