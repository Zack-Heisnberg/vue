const { google } = require('googleapis')
// const fs = require('fs')
const key = require('../config/gdrive.json')
// const drive = google.drive('v3')
const jwtClient = new google.auth.JWT(
  key.client_email,
  null,
  key.private_key,
  ['https://www.googleapis.com/auth/drive'],
  null
)
module.exports = async function () {
  await jwtClient.authorize()
}

/*
async function zack() {
  let cred
  await jwtClient
    .authorize()
    .then((creds) => {
      cred = creds
    })
    .catch((err) => {
      console.log(err)
    })
} 
  // Make an authorized requests
  const fileMetadata = {
    name: 'neo.txt',
    parents: ['10bD0YQqArL13MJ8ogMp3kCEmu9aJRRBI'],
  }

  const media = {
    mimeType: 'text/plain',
    body: fs.createReadStream('./neo.txt'),
  }
 
  drive.files.create(
    {
      auth: jwtClient,
      resource: fileMetadata,
      media,
      fields: 'id',
    },
    (err, file) => {
      if (err) {
        console.log(err)
        return
      }
      console.log(file.data.id)
    }
  )
  // List Drive files.

  drive.files.list({ auth: jwtClient }, (listErr, resp) => {
    console.log('ewqvskfldjkgbs')
    // console.log(resp.data.files)
    resp.data.files.forEach(async (file) => {
      if (file.name == 'neo.txt') {
        let fileId = file.id
        console.log(file.id)
        await drive.files.delete({ auth: jwtClient, fileId: fileId }).then(
          async function (response) {
            console.log(response)
          },
          function (err) {
            console.log(err)
          }
        )
      }
      console.log(`${file.name} (${file.mimeType})`)
    })
  })
  */
