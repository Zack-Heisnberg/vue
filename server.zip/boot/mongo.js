//require mongoose module
const mongoose = require('mongoose')
const logger = require('pino')()

//export this function and imported by server.js
module.exports = async function () {
  try {
    await mongoose.connect(process.env.MONGO_HOST, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      poolSize: 10,
      useFindAndModify: false,
      useCreateIndex: true,
    })
  } catch (err) {
    throw new Error(err)
  }

  mongoose.connection.on('connected', function () {
    logger.info(
      'Mongoose default connection is open to ',
      process.env.MONGO_HOST
    )
  })
  mongoose.connection.on('reconnected', function () {
    logger.info(
      'Mongoose default reconnection is open to ',
      process.env.MONGO_HOST
    )
  })

  mongoose.connection.on('error', function (err) {
    logger.error('Mongoose default connection has occured ' + err + ' error')
  })

  mongoose.connection.on('disconnected', function () {
    logger.error('Mongoose  disconnected')
  })

  process.on('SIGINT', function () {
    mongoose.connection.close(function () {
      logger.error('Mongoose  termination')
      process.exit(0)
    })
  })
}
